/* eslint-disable eol-last */
/* eslint-disable indent */
class HeroContent extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    render() {
        this.innerHTML = `
        <div class="hero">
          <div class="heroInner">
            <h1 class="heroTitle">Welcome to AW Resto</h1>
            <p class="heroTagline">"Temukan Restaurant Favorite Anda"</p>
          </div>
        </div>
        `;
    }
}

customElements.define('hero-content', HeroContent);