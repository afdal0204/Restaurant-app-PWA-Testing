/* eslint-disable eol-last */
/* eslint-disable indent */
class footerElement extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    render() {
        this.innerHTML = `
    <style>
    .footer {
      background-color: #40a57b;
      color: rgb(243, 238, 238);
      padding: 1.5rem;
      font-size: 1.2rem;
      text-align: center;
      margin-bottom: auto;
      }

      @media screen and (min-width: 650px) {
        .footer{
          font-size: 12px;
        }
      }

      @media screen and (min-width: 780px) {
        .footer{
          font-size: 15px;
        }
      }

      @media screen and (min-width: 1000px) {
        .footer{
          font-size: 17px;
        }
      }


    </style>
    <div class="footer">
    <p>© 2023 Copyright by Afdal Wahyi</p>
    </div>
        `;
    }
}

customElements.define('footer-element', footerElement);